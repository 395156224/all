// The Vue build version to load with the `import` command
import Vue from 'vue';
import App from '../More';
/* eslint-disable */
new Vue ({
  el: '#more',
  render: h => h(App),
});
