# webpack-template
一个webpack多入口模板
