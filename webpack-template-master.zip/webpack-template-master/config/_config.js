'use strict'
 module.exports = {
  appName: 'demo',
  projectName: 'demo2'
}
